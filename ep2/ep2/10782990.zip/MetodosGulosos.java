package ep2;

/*********************************************************************/
/** ACH 2002 - Introducao a Ciencia da Computacao II                **/
/** EACH-USP - Segundo Semestre de 2010                             **/
/**                                                                 **/
/** <04> - <Norton Trevisan Roman>                                   **/
/**                                                                 **/
/** Terceiro Exercicio-Programa                                     **/
/**                                                                 **/
/** <Arthur Prince de Almeida> <10782990>                              **/
/**                                                                 **/
/*********************************************************************/


/** 
	COMENTARIOS GERAIS
	
	Seguindo os criterios de selecao, um objeto só poderá ser colocado na 
	mochila caso ela suporte o total de peso.
	
	O total de peso ao se colocar um objeto (do tipo Objeto) é dado por 
	mochila.getPesoUsado() + objeto.getPeso()
	
	Colocar um objeto na mochila significa alterar os seguintes campos da mochila:
	
	pesoUsado,
	
	valorDentroDaMochila, e 
	
	numObjetosNaMochila.
*/
public abstract class MetodosGulosos {
	
	

	/**
		Este método deve implementar um algoritmo guloso que selecione objetos
		da listaDeObjetosDisponiveis a serem colocados na mochila, de acordo
		com o critério 'objetos de menor peso primeiro'. Caso dois objetos
		tenham o mesmo peso, o critério de desempate será 'objetos de maior 
		valor primeiro' (apenas para os empates em peso).
		
		@param pesoMaximoDaMochila Peso máximo suportado pela mochila
		@param listaDeObjetosDisponiveis Arranjo de objetos considerados no problema
		
		@return Mochila carregada conforme essa estratégia
	 */
	 public static void insercaoAux(Objeto[] a) {
		for(int i=1; i<a.length; i++) {
			Objeto aux = a[i];
			int j = i;
			while ((j > 0) && (aux.getPeso() <= a[j-1].getPeso())) {
				if(aux.getPeso() == a[j-1].getPeso()){
					if(aux.getValor() < a[j-1].getValor()) break;
				}
				a[j] = a[j-1];
				j--;
			}
			a[j] = aux;
		}
	}
	
	public static void insercaoAux2(Objeto[] a) {
		for(int i=1; i<a.length; i++) {
			Objeto aux = a[i];
			int j = i;
			while ((j > 0) && (aux.getValor() <= a[j-1].getValor())) {
				if(aux.getValor() == a[j-1].getValor()){
					if(aux.getPeso() < a[j-1].getPeso()) break;
				}
				a[j] = a[j-1];
				j--;
			}
			a[j] = aux;
		}
	}
	
	public static void insercaoRelacaoDeValorPorPeso(Objeto[] a) {
		for(int i=1; i<a.length; i++) {
			Objeto aux = a[i];
			int j = i;
			while ((j > 0) && (aux.getValor()/aux.getPeso() >= a[j-1].getValor()/a[j-1].getPeso())) {
				if(aux.getValor()/aux.getPeso() == a[j-1].getValor()/a[j-1].getPeso()){
					if(aux.getValor()<a[j-1].getValor()) break;
				}
				a[j] = a[j-1];
				j--;

			}
			a[j] = aux;
		}
	}
	public static Mochila utilizaMenorPeso(double pesoMaximoDaMochila, Objeto[] listaDeObjetosDisponiveis) {
		Mochila mochila = new Mochila(pesoMaximoDaMochila);
		insercaoAux(listaDeObjetosDisponiveis);
		int numDeObjetos = 0;
		double pesoUsado = 0;
		double valor = 0;
		
		while(pesoUsado+listaDeObjetosDisponiveis[numDeObjetos].getPeso() <= pesoMaximoDaMochila && numDeObjetos<listaDeObjetosDisponiveis.length){
			pesoUsado+=listaDeObjetosDisponiveis[numDeObjetos].getPeso();
			valor+=listaDeObjetosDisponiveis[numDeObjetos].getValor();
			numDeObjetos++;
		}
		mochila.setPesoUsado(pesoUsado);
		mochila.setValorDentroDaMochila(valor);
		mochila.setNumObjetosNaMochila(numDeObjetos);
		return mochila;
	}

	
	/** 
		Este método deve implementar um algoritmo guloso que selecione objetos
		da listaDeObjetosDisponiveis a serem colocados na mochila, de acordo
		com o critério 'objetos de maior valor primeiro'. Caso dois objetos
		tenham o mesmo valor, o critério de desempate sera 'objetos de menor peso
		primeiro' (apenas para os empates em valor).
		
		@param pesoMaximoDaMochila Peso máximo suportado pela mochila
		@param listaDeObjetosDisponiveis Arranjo de objetos considerados no problema
		
		@return Mochila carregada conforme essa estratégia
	 */
	public static Mochila utilizaMaiorValor(double pesoMaximoDaMochila,	Objeto[] listaDeObjetosDisponiveis) {
		Mochila mochila = new Mochila(pesoMaximoDaMochila);
		insercaoAux2(listaDeObjetosDisponiveis);
		int numDeObjetos = 0;
		double pesoUsado = 0;
		double valor = 0;
		
		for(int i = listaDeObjetosDisponiveis.length-1; i >=0; i--){
			if(listaDeObjetosDisponiveis[i].getPeso()+pesoUsado<=pesoMaximoDaMochila){
				pesoUsado+=listaDeObjetosDisponiveis[i].getPeso();
				valor+=listaDeObjetosDisponiveis[i].getValor();
				numDeObjetos++;
			}
			
		}
		mochila.setPesoUsado(pesoUsado);
		mochila.setValorDentroDaMochila(valor);
		mochila.setNumObjetosNaMochila(numDeObjetos);
		
		
		
		return mochila;
	}

	
	/**
		Este método deve implementar um algoritmo guloso que selecione objetos
		da listaDeObjetosDisponiveis a serem colocados na mochila, de acordo
		com o critério 'objetos de maior valor/peso primeiro (valor dividido por
		peso primeiro)'. Caso dois objetos tenham o mesmo valor/peso, o critério
		de desempate sera 'objetos de maior peso primeiro' (apenas para os empates).
		
		@param pesoMaximoDaMochila Peso máximo suportado pela mochila
		@param listaDeObjetosDisponiveis Arranjo de objetos considerados no problema
		
		@return Mochila carregada conforme essa estratégia
	 */
	public static Mochila utilizaMaiorValorDivididoPorPeso(double pesoMaximoDaMochila, Objeto[] listaDeObjetosDisponiveis) {
		Mochila mochila = new Mochila(pesoMaximoDaMochila);

		insercaoRelacaoDeValorPorPeso(listaDeObjetosDisponiveis);
		int numDeObjetos = 0;
		double pesoUsado = 0;
		double valor = 0;
		
		for(int i = 0; i <listaDeObjetosDisponiveis.length; i++){
			if(listaDeObjetosDisponiveis[i].getPeso()+pesoUsado<=pesoMaximoDaMochila){
				pesoUsado+=listaDeObjetosDisponiveis[i].getPeso();
				valor+=listaDeObjetosDisponiveis[i].getValor();
				numDeObjetos++;
			}
			
		}
		mochila.setPesoUsado(pesoUsado);
		mochila.setValorDentroDaMochila(valor);
		mochila.setNumObjetosNaMochila(numDeObjetos);

		return mochila;
	}

	
}
